a = 25
b = 17
c = -4

if a < b and b > c:
    print("A is smaller than B or B is greater than C")

elif b > a:
    print("B is greater than A")

elif c < b:
    print("C is smaller than B")

if a > b:
    print("A is greater than B")

else:
    print("No condition was executed")


