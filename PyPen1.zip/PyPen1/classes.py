class BasicMath:
    
    def summing(self, a, b):
        return a + b
    
    def multy(self, a, b):
        return a * b
    
    def raiseit(self, a, b):
        return a**b

first_calc = BasicMath() 
first_class.multy(8,3) 
second_calc = BasicMath() 
second_calc.raiseit(4,5) 
